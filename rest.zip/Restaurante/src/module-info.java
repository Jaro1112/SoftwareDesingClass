/**
 * 
 */
/**
 * 
 */
module Restaurante {
	requires java.desktop;
}