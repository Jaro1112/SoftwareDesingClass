package Restaurante.Pkg;

 // provedores  que se usaran en el restaurante

public enum Proveedor {
	COLANTA, PASTOPASTO, COLACTEOS, ROA, CARNESSABASTIAN, SURTITODO, PAPASRAFAEL,SEVILLA,
}
