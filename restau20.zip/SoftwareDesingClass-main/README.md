# SoftwareDesingClass
Repositorio principal para el desarrollo del proyecto de la clase diseño de software

Realizado por
Zarella Burbano
Kevin Chachinoy
Lina Viveros
Julian Rodriguez 
